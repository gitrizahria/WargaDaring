<?php include('../_partials/top.php') ?>
<!--
<h1 class="page-header">Dasbor</h1>
-->
<?php include('data-index.php') ?>
<!-- dashbord template -->
<div class="row">
      <div class="panel well">
        <div class="row">
            <div class="col-md-12">
                <h2><center><strong><font color="blue">Hai <?php echo $_SESSION['user']['nama_user'];?><i class="fa fa-user"></i></font></strong></center></h2><span></span>
                    <div class="col-xs-12">
                    <font color="grey"><h4>Selamat datang di Aplikasi Kependudukan Kelurahan Uhamka - Jakarta Timur</h4>
                    </font>
                     </div>
                </div>
              </div>
              </div>
      <div>
      <h2 style="color: blue;"> <center><strong>Coming Soon...</strong></center> </h2>
      </div>
</div>
<?php include('../_partials/bottom.php') ?>
